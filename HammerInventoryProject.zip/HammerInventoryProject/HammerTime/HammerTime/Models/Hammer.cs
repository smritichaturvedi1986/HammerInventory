﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HammerTime.Models
{
    public class Hammer
    {
        public int HammerId { get; set; }
        public int Size { get; set; }
        public string type { get; set; }
        
    }
}